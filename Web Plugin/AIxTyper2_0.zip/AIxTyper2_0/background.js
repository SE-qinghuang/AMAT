chrome.runtime.onMessage.addListener(function (request, sender, sendResponse){
    console.log('request', request);
    console.log('sender', sender);

     if (request.action == 'infer') {
     fetch('http://103.146.50.137:8002/login', {                      //'http://127.0.0.1:5000/login'
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    co_area: request.co_area,
    co_name: request.co_name,
    co_top : request.co_top,
    co_all : request.co_all,
    model: request.model
  }),
   mode: 'cors'
}).then(function(response) {

  return response.text()
}).then(function(data) {
    console.log(data)
    return  sendResponse({data: data});
});

     return true;
     }





      //   $.ajax({
      //       url:'http://localhost:9999/login',
      //       method: 'POST',
      //       data: {
      //           co_area: request.co_area,
      //           co_name: request.co_name,
      //           co_top : request.co_top,
      //           co_all : request.co_all,
      //           model: request.model
      //       },
      //       asyne: true
      //   }).done(function (data) {
      //       // console.log('transData', data);
      //       sendResponse({
      //           data: data
      //       });
      //   });
      // }

     else {
        //todo
    }


});



