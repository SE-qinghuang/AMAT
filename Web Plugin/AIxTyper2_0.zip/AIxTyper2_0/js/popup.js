//获取btnInfer按钮
var btnBuildTest = document.getElementById("btnInfer");
//绑定点击事件，发送请求

btnBuildTest.onclick = function () {
    var co_area = document.getElementById("code_area").value
    var co_name = document.getElementById("sim_name").value
    var co_top = document.getElementById("top").value
    var co_all = document.getElementById("all_code").value
    // if (isNa(co_area) && isNa(co_name)) {
    //     return;
    // }
     if (!isNaN(co_area)) {
         alert("code is not a number")
        return; // 如果全是数字，直接返回
    }

    if(co_area){
        chrome.runtime.sendMessage({
            action: "infer",
            co_area: co_area,
            co_name: co_name,
            co_top : co_top,
            co_all : co_all,
            model: "popup"
        },
        function(f) {
             if(f.data){
            //将翻译结果显示在result中
            //      alert(f.data)
            document.getElementById("insert_div").innerHTML="<pre class='pi'>"+f.data;
          }
        });
    }document.getElementById("insert_div").innerHTML="waiting..."
}
//选择all会固定Top1。
$(function(){
    var models = new Array(1);
    models[0] = new Array("top-1","top-2","top-3","top-4","top-5");
    models[1] = new Array("top-1");

    $("#all_code").change(function(){
        $("#top").empty();
        var val = this.value;
        $.each(models,function(i,n){
            if(val==i){
                $.each(models[i], function(j,m) {
                    var textNode = document.createTextNode(m);
                    var opEle = document.createElement("option");
                    $(opEle).append(textNode);
                    $(opEle).appendTo($("#top"));
                });
            }
        });

    });
});